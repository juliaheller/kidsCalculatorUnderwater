Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - mad-monkey ( https://freesound.org/people/mad-monkey/ )

You can find this pack online at: https://freesound.org/people/mad-monkey/packs/4305/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 66698__mad_monkey__002.wav
    * url: https://freesound.org/s/66698/
    * license: Creative Commons 0
  * 66696__mad_monkey__000.wav
    * url: https://freesound.org/s/66696/
    * license: Creative Commons 0
  * 66697__mad_monkey__001.wav
    * url: https://freesound.org/s/66697/
    * license: Creative Commons 0
  * 66700__mad_monkey__004.wav
    * url: https://freesound.org/s/66700/
    * license: Creative Commons 0
  * 66701__mad_monkey__005.wav
    * url: https://freesound.org/s/66701/
    * license: Creative Commons 0
  * 66699__mad_monkey__003.wav
    * url: https://freesound.org/s/66699/
    * license: Creative Commons 0
  * 66703__mad_monkey__007.wav
    * url: https://freesound.org/s/66703/
    * license: Creative Commons 0
  * 66704__mad_monkey__008.wav
    * url: https://freesound.org/s/66704/
    * license: Creative Commons 0
  * 66702__mad_monkey__006.wav
    * url: https://freesound.org/s/66702/
    * license: Creative Commons 0
  * 66705__mad_monkey__009.wav
    * url: https://freesound.org/s/66705/
    * license: Creative Commons 0
  * 66706__mad_monkey__010.wav
    * url: https://freesound.org/s/66706/
    * license: Creative Commons 0


